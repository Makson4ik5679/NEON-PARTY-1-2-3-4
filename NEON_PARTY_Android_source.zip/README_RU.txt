NEON PARTY — Android project

Что уже настроено:
- Экран зафиксирован в горизонтальной ориентации (landscape).
- Системные панели Android скрываются в immersive fullscreen.
- Игра загружается локально из app/src/main/assets/index.html — интернет для запуска не нужен.
- WebView включает JavaScript и DOM Storage.
- Джойстики остаются в углах: P1 снизу слева, P2 снизу справа, P3 сверху слева, P4 сверху справа.
- В кликере джойстиков нет: только кнопки кликера.

Сборка APK:
1. Откройте папку проекта в Android Studio.
2. Дождитесь установки Gradle/Android SDK компонентов.
3. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Application ID: com.neonparty.game
Min Android: 6.0 (API 23)
